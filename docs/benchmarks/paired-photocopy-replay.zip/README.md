# MedExtract paired laboratory OCR benchmark

Original synthetic layouts, annotations and accompanying benchmark data: AdrianPerez3, CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/

LOINC® content retains its separate license. See LOINC_short_license.txt,
licenses/LoincLicense_5.8.txt, and inputs/paired-ocr-terminology.json.
The implementation and scoring code are available in the generator repository under its MIT license.
https://github.com/AdrianPerez3/medextract-lab-generator

The compact replay contains saved decisions and their exact reference annotations.
All referenced original page images are identified by their SHA-256 in inputs/reports.jsonl.
The optional full replica additionally includes those page images.
See the repository study for how to regenerate pages, replay scores and interpret denominators.
The numbers and layouts are synthetic.
